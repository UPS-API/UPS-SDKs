import base64
from os import error
from .token_info import LoginInfo
from .ups_oauth_response import UpsOauthResponse, ErrorResponse, ErrorModel
from typing import Generic , TypeVar, List, Optional
from .auth_code_constants import AuthCodeConstants
import requests
from urllib.parse import urlencode, quote_plus
import json
from typing import Any, Dict
import aiohttp
import asyncio

class AuthCodeService:
    def __init__(self, http_client):
        self.http_client = http_client
        self.base_url = AuthCodeConstants.BASE_URL        

    async def login(self, query_params=None):
        try:
            url = self.build_url_with_query_params(f"{self.base_url}/authorize", None)
            httpHeaders = {
                "Content-Type" : "application/x-www-form-urlencoded"
            }

            get_timeout = aiohttp.ClientTimeout(
                total=None, # total time taken to make a connection or waiting for a response
                sock_connect=AuthCodeConstants.GET_TIMEOUT, # Maximal number of seconds for connecting to a peer for a new connection, not given from a pool. See also connect.
                sock_read=AuthCodeConstants.GET_TIMEOUT # Maximal number of seconds for reading a portion of data from a peer
            )
            async with self.http_client.ClientSession(headers=httpHeaders, timeout=get_timeout) as session:            
                response = await session.get(url, params=query_params)
                if response.status == 200:
                    redirect_url = str(response.url)
                    check = self.login_response(redirect_url)
                    return check
                else:
                    json_data = await response.json()
                    return self.login_error_response(json_data)        
        except asyncio.TimeoutError:
            return self.login_error_response(AuthCodeConstants.TIMED_OUT)
        except Exception as e:
            return self.login_error_response(AuthCodeConstants.INTERNAL_SERVER_ERROR)

    async def get_access_token(self, client_id, client_secret, redirect_uri, auth_code):
        try:            
            body = {
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
                "code": auth_code
            }
            b = await self.post_for_token_info(f"{self.base_url}/token", body, client_id, client_secret)
            return b
        except asyncio.TimeoutError:
            return self.api_error_response(AuthCodeConstants.TIMED_OUT)
        except Exception as e:
            return self.api_error_response(AuthCodeConstants.INTERNAL_SERVER_ERROR)

    async def get_access_token_from_refresh_token(self, client_id, client_secret, refresh_token):
        try:            
            body = {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token
            }
            return await self.post_for_token_info(f"{self.base_url}/refresh_token", body, client_id, client_secret)
        except asyncio.TimeoutError:
            return self.api_error_response(AuthCodeConstants.TIMED_OUT)
        except Exception as e:
            return self.api_error_response(AuthCodeConstants.INTERNAL_SERVER_ERROR)

    async def post_for_token_info(self, url, body, clientId, clientSecret):
        try:
            httpHeaders = {
                "Content-Type" : "application/x-www-form-urlencoded",                
                "Authorization": "Basic " + base64.b64encode(f"{clientId}:{clientSecret}".encode("ascii")).decode("ascii")
            }
            post_timeout = aiohttp.ClientTimeout(
                total=None, 
                sock_connect=AuthCodeConstants.POST_TIMEOUT, 
                sock_read=AuthCodeConstants.POST_TIMEOUT 
            )
            async with self.http_client.ClientSession(headers=httpHeaders, timeout=post_timeout) as session:            
                response = await session.post(url, data=body)
                json_response = await response.json()
                if response.status == 200:
                    return self.api_response(json_response)
                else:
                    return self.api_error_response(json_response)
        except asyncio.TimeoutError:
            return self.api_error_response(AuthCodeConstants.TIMED_OUT)
        except Exception as e:
            return self.api_error_response(AuthCodeConstants.INTERNAL_SERVER_ERROR)    

    def build_url_with_query_params(self, base_url, query_params):
        if query_params is None:
            return base_url
        query_string = urlencode(query_params, quote_via=quote_plus)
        return f"{base_url}?{query_string}"

    def api_response(self, json_data):
        token_info = {
            "access_token": json_data["access_token"],
            "client_id": json_data["client_id"],
            "expires_in": json_data["expires_in"],
            "issued_at": json_data["issued_at"],
            "refresh_token": json_data["refresh_token"],
            "refresh_token_expires_in": json_data["refresh_token_expires_in"],
            "refresh_token_issued_at": json_data["refresh_token_issued_at"],
            "refresh_token_status": json_data["refresh_token_status"],
            "status": json_data["status"],
            "token_type": json_data["token_type"]
        }
        return UpsOauthResponse(response=token_info, error=None).to_dict()

    def api_error_response(self, json_data: Dict) -> UpsOauthResponse:
            response_str = json_data #json_data.get("response", "{}")            
            error_response = json.loads(str(response_str).replace("'", '"'), object_hook= self.custom_object_hook)                        
            return UpsOauthResponse(response=None, error= error_response).to_dict()         

    def login_response(self, redirect_uri: str) -> UpsOauthResponse:
        loginInfo = LoginInfo(redirect_uri=redirect_uri)
        return UpsOauthResponse(response=loginInfo.to_dict(), error=None).to_dict()

    def login_error_response(self, json_data: Any) -> UpsOauthResponse:        
            response_str =  json_data #json_data.get("response", "{}")
            error_response = json.loads(str(response_str).replace("'", '"'), object_hook= self.custom_object_hook)  
            return UpsOauthResponse(response =None, error = error_response).to_dict()        
    
    def custom_object_hook(self, dct):
        if "code" in dct and "message" in dct:            
            return {"code": dct["code"], "message": dct["message"]}
        return dct

