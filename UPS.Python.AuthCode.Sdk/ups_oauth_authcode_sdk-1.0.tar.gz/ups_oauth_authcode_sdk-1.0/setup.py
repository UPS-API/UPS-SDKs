from setuptools import setup
setup(
    name="ups_oauth_authcode_sdk",
    version=1.0,
    description="This is package for maiking OAuth(Auth Code workflow) request to get access token to access ups endpoints.",
    long_description="This is package for maiking OAuth request to get access token to access ups endpoints.",
    author="UPS",    
    license='MIT',
    packages=['ups_oauth_authcode_sdk'],
    install_requires=[])
