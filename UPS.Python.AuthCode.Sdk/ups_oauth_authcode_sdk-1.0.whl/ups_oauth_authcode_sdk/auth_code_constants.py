class AuthCodeConstants:
    AUTHORIZE_URL = "https://onlinetools.ups.com/security/v1/oauth/authorize"
    TOKEN_URL = "https://onlinetools.ups.com/security/v1/oauth/token"
    REFRESH_TOKEN_URL = "https://onlinetools.ups.com/security/v1/oauth/refresh"
    GET_TIMEOUT = 15  # Timeout in seconds, adjusted from milliseconds
    POST_TIMEOUT = 15  # Timeout in seconds, adjusted from milliseconds
    INTERNAL_SERVER_ERROR = "{\"code\":\"10500\",\"message\":\"Internal Server Error.\"}"
    UNABLE_TO_REDIRECT = "{\"code\":\"10400\",\"message\":\"Unable to redirect: Response or RequestUri is null.\"}"
    TIMED_OUT = "{\"code\":\"10500\",\"message\":\"Request Timed out.\"}"
    BASE_URL = "https://onlinetools.ups.com/security/v1/oauth"
