from typing import Generic, TypeVar, List, Optional
from pydantic import BaseModel, Field
import json

T = TypeVar('T')

class UpsOauthResponse(Generic[T]):
    def __init__(self, response: T = None, error: 'ErrorResponse' = None):
        self.response = response
        self.error = error
        
    def to_dict(self):
        return {
            "response": self.response,
            "error": self.error,
        }

class ErrorResponse:
    def __init__(self, errors: List['ErrorModel']):
        self.errors = errors        

class ErrorModel:
    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message  