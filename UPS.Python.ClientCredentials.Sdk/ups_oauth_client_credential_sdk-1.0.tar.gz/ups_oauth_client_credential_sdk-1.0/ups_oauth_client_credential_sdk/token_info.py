from pydantic import BaseModel, Field
import json

class TokenInfo(BaseModel):
    refresh_token_expires_in: str = Field(..., alias='refresh_token_expires_in')
    refresh_token_status: str = Field(..., alias='refresh_token_status')
    issued_at: str = Field(..., alias='issued_at')
    token_type: str = Field(..., alias='token_type')
    client_id: str = Field(..., alias='client_id')
    access_token: str = Field(..., alias='access_token')
    refresh_token: str = Field(..., alias='refresh_token')
    refresh_token_issued_at: str = Field(..., alias='refresh_token_issued_at')
    expires_in: str = Field(..., alias='expires_in')
    status: str = Field(..., alias='status')
    
    def to_dict(self):
            return {
                "issued_at": self.issued_at,
                "token_type": self.token_type,
                "client_id": self.client_id,
                "access_token": self.access_token,
                "expires_in": self.expires_in,
                "status": self.status
            }
