import requests
import base64
import json
import asyncio
import aiohttp
import http.client
from typing import Any, Dict
from .client_credential_constants import ClientCredentialConstants
from .ups_oauth_response import UpsOauthResponse, ErrorResponse, ErrorModel

class ClientCredentialService:
    def __init__(self, http_client):
        self.aiohttp = http_client;
     
    async def get_access_token(self, clientId, clientSecret, headers=None, customClaims=None):
        try:
            url = ClientCredentialConstants.BASE_URL
            http_headers = {
                "Content-Type" : "application/x-www-form-urlencoded",
                "Cookie" : "ups_language_preference=en_US",
                "Authorization": "Basic " + base64.b64encode(f"{clientId}:{clientSecret}".encode("ascii")).decode("ascii")
            }
            post_timeout = self.aiohttp.ClientTimeout(
                total=None, 
                sock_connect=ClientCredentialConstants.POST_TIMEOUT, 
                sock_read=ClientCredentialConstants.POST_TIMEOUT 
            )

            if headers:
                for key, value in headers.items():
                    http_headers[key] = value

            body = {
                "grant_type": "client_credentials",
                "scope": "public"
            }
           
            if customClaims:
                claims = {}
                for key, value in customClaims.items():
                    claims[key] = value
                    body["custom_claims"] = json.dumps(claims)
                    
            async with self.aiohttp.ClientSession(headers=http_headers, timeout=post_timeout) as session:
                response = await session.post(url, data=body)
                json_response = await response.json()
                if response.status == 200:
                    return self.api_response(json_response)
                else:
                    return self.api_error_response(json_response)
        except requests.exceptions.Timeout:
            res = json.loads(ClientCredentialConstants.TIMED_OUT)
            return self.api_error_response(res)
        except Exception:
            return self.api_error_response(ClientCredentialConstants.INTERNAL_SERVER_ERROR);

    def api_response(self, json_data):
        token_info = {
            "access_token": json_data["access_token"],
            "client_id": json_data["client_id"],
            "expires_in": json_data["expires_in"],
            "issued_at": json_data["issued_at"],
            "status": json_data["status"],
            "token_type": json_data["token_type"]
        }
        return UpsOauthResponse(response=token_info, error=None).to_dict()
    
    def api_error_response(self, json_data: Dict) -> UpsOauthResponse:
        response_str = json_data           
        error_response = json.loads(str(response_str).replace("'", '"'), object_hook= self.custom_object_hook)                        
        return UpsOauthResponse(response=None, error= error_response).to_dict()   
    
    def custom_object_hook(self, dct):
        if "code" in dct and "message" in dct:            
            return {"code": dct["code"], "message": dct["message"]}
        return dct

     

